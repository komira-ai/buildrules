int ok;
